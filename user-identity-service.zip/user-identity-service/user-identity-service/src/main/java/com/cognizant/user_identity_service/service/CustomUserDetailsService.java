package com.cognizant.user_identity_service.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cognizant.user_identity_service.entity.UserCredentials;
import com.cognizant.user_identity_service.repository.UserCredentialRepository;

public class CustomUserDetailsService	implements UserDetailsService {
	
	@Autowired
	private UserCredentialRepository repository;
	
	

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        Optional<UserCredentials> credential = repository.findByUserName(userName);
        return credential.map(customUserDetails::new).orElseThrow(() -> new UsernameNotFoundException("user not found with name :" + userName));
    }

}
