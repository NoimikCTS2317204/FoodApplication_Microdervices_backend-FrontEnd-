package com.cognizant.user_identity_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.user_identity_service.entity.UserCredentials;
import com.cognizant.user_identity_service.repository.UserCredentialRepository;

@Service
public class AuthService {
	@Autowired
	private UserCredentialRepository userCredentialrepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	@Autowired
	private JwtService jwtService;
	
	
	public String SaveUser(UserCredentials userCredentials) {
		userCredentials.setUserPassword(passwordEncoder.encode(userCredentials.getUserPassword()));
		
		userCredentialrepository.save(userCredentials);
		return "User Saved SuccessFully ";
		
	}
	
	public String GenerateToken(String userName) {
		return jwtService.generateToken(userName);
		
	}
	public void ValidateToken(String Token) {
		 jwtService.validateToken(Token);
	}
	
	public List<UserCredentials> allUsers(){
		return userCredentialrepository.findAll();
	}

}
