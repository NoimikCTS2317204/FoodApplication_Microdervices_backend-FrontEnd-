package com.cognizant.user_identity_service.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.user_identity_service.dto.AuthRequest;
import com.cognizant.user_identity_service.entity.UserCredentials;
import com.cognizant.user_identity_service.service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")

public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	@Autowired
	private AuthenticationManager authManager;
	
	
	
	@PostMapping("/register")
    public String addNewUser(@RequestBody UserCredentials user) {
        return authService.SaveUser(user);
    }

	@PostMapping("/token")
	public Map<String, String> getToken(@RequestBody AuthRequest authRequest) {
	    Authentication authenticate = authManager.authenticate(
	        new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getUserPassword())
	    );
	    if (authenticate.isAuthenticated()) {
	        String token = authService.GenerateToken(authRequest.getUserName());
	        Map<String, String> response = new HashMap<>();
	        response.put("token", token);
	        return response;
	    } else {
	        throw new RuntimeException("User is Invalid");
	    }
	}
	

    @GetMapping("/validate")
    public String validateToken(@RequestParam("token") String token) {
    	authService.ValidateToken(token);
        return "Token is valid";
    }
    

    
    
    
    
    
    
    
    
    
    
    @GetMapping("/getAllUser")
    public List<UserCredentials> getAllUser() {
    	return authService.allUsers();
    }
	
	

}
