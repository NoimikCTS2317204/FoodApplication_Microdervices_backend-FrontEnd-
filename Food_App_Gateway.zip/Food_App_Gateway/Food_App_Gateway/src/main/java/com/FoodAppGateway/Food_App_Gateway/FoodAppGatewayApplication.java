package com.FoodAppGateway.Food_App_Gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodAppGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodAppGatewayApplication.class, args);
	}

}
