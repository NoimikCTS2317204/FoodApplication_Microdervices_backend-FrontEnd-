package com.FoodAppGateway.Food_App_Gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
public class AppConfig {

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        http
            .csrf().disable() // Disable CSRF protection
            .authorizeExchange()
            .pathMatchers("/auth/**").permitAll() // Allow unauthenticated access to auth endpoints
            .anyExchange().authenticated(); // Require authentication for all other endpoints

        return http.build();
    }
}
